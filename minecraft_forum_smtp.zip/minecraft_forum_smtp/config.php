<?php
// config.php
// 這份檔案集中管理網站、資料庫與 SMTP 寄信設定。
// 重點：Gmail 應用程式密碼不要上傳到 GitHub。交作業前請確認沒有公開真實密碼。

// ===== 網站基本設定 =====
define('APP_NAME', 'MineForum 方塊論壇');
define('BASE_URL', 'http://localhost/minecraft_forum_smtp');
define('TIMEZONE', 'Asia/Taipei');

// ===== 資料庫設定 =====
define('DB_HOST', 'localhost');
define('DB_NAME', 'minecraft_forum_smtp');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// ===== 寄信模式 =====
// smtp：使用 Gmail SMTP 真正寄信
// log ：不真的寄出，只把 .eml 存到 storage/outbox，適合本機 demo 或沒有網路時測試
define('MAIL_DRIVER', 'smtp');
define('MAIL_ALWAYS_SAVE_COPY', true);

// ===== Gmail SMTP 設定 =====
// Gmail SMTP 官方常用設定：smtp.gmail.com + 587 + STARTTLS。
// SMTP_PASSWORD 請填「Google 應用程式密碼」，不是 Gmail 登入密碼。
// Google 顯示的 16 碼驗證碼常有空格，貼上時請把空格拿掉。
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls'); // tls = STARTTLS 587；ssl = 465
define('SMTP_USERNAME', 'your_gmail@gmail.com');
define('SMTP_PASSWORD', 'your_16_digit_app_password_without_spaces');
define('SMTP_TIMEOUT', 20);

// ===== 寄件者資訊 =====
// Gmail 通常要求 From 與 SMTP_USERNAME 同一個信箱，否則可能被 Gmail 改寫或拒收。
define('MAIL_FROM_EMAIL', SMTP_USERNAME);
define('MAIL_FROM_NAME', 'MineForum 系統通知');

// ===== Demo 老師測試信箱 =====
define('TEACHER_TEST_EMAIL', 'hw.pcchen@google.com');
define('TEACHER_TEST_NAME', 'PC Chen 老師');

// ===== 上傳與限制 =====
define('MAX_POST_LENGTH', 10000);
define('MAX_IMAGE_SIZE', 3 * 1024 * 1024);
define('ALLOWED_IMAGE_MIME', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);
