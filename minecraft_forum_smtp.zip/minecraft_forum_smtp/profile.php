<?php
// profile.php
// 玩家可以修改自己的暱稱、Email、顏色、大頭貼。
require_once __DIR__ . '/functions.php';
start_session_once();
require_login();
$user = current_user($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nickname = trim($_POST['nickname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $favoriteColor = safe_color($_POST['favorite_color'] ?? '#c8e6a0');
    $avatar = $_POST['avatar'] ?? 'steve';

    if ($nickname === '' || mb_strlen($nickname) > 40) {
        flash_set('error', '暱稱不可空白，且最多 40 字。');
        redirect('profile.php');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash_set('error', 'Email 格式不正確。');
        redirect('profile.php');
    }
    if (!array_key_exists($avatar, avatar_options())) {
        $avatar = 'steve';
    }

    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id <> ? LIMIT 1');
    $stmt->execute([$email, $user['id']]);
    if ($stmt->fetch()) {
        flash_set('error', '這個 Email 已被其他會員使用。');
        redirect('profile.php');
    }

    $stmt = $pdo->prepare('UPDATE users SET nickname = ?, email = ?, favorite_color = ?, avatar = ? WHERE id = ?');
    $stmt->execute([$nickname, $email, $favoriteColor, $avatar, $user['id']]);
    flash_set('success', '個人資料已更新。');
    redirect('profile.php');
}

$user = current_user($pdo);
page_header('個人資料', $user);
?>
<section class="settings-wrap">
    <div class="pixel-card auth-card wide-auth">
        <div class="card-title">玩家資料設定</div>
        <?php if ($msg = flash_get('success')): ?><div class="alert success"><?= h($msg) ?></div><?php endif; ?>
        <?php if ($msg = flash_get('error')): ?><div class="alert error"><?= h($msg) ?></div><?php endif; ?>

        <form method="post" class="form-stack">
            <?= csrf_field() ?>
            <div class="form-grid">
                <label>帳號
                    <input type="text" value="<?= h($user['username']) ?>" disabled>
                </label>
                <label>角色
                    <input type="text" value="<?= h($user['role']) ?>" disabled>
                </label>
                <label>暱稱
                    <input type="text" name="nickname" value="<?= h($user['nickname']) ?>" maxlength="40" required>
                </label>
                <label>Email
                    <input type="email" name="email" value="<?= h($user['email']) ?>" maxlength="255" required>
                </label>
            </div>

            <label>喜歡顏色</label>
            <div class="choice-grid color-grid">
                <?php foreach (color_options() as $value => $label): ?>
                    <label class="choice-card">
                        <input type="radio" name="favorite_color" value="<?= h($value) ?>" <?= $user['favorite_color'] === $value ? 'checked' : '' ?>>
                        <span class="color-dot" style="background: <?= h($value) ?>"></span>
                        <span><?= h($label) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>

            <label>大頭貼圖案</label>
            <div class="choice-grid avatar-grid">
                <?php foreach (avatar_options() as $key => $icon): ?>
                    <label class="choice-card avatar-choice">
                        <input type="radio" name="avatar" value="<?= h($key) ?>" <?= $user['avatar'] === $key ? 'checked' : '' ?>>
                        <span class="avatar-preview"><?= $icon ?></span>
                        <span><?= h($key) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>

            <button class="btn" type="submit">儲存玩家資料</button>
        </form>
    </div>
</section>
<?php page_footer(); ?>
