<?php
// email_logs.php
// 相容舊作業 6 檔名，實際寄信紀錄已整合在 mailer_panel.php。
require_once __DIR__ . '/functions.php';
redirect('mailer_panel.php');
