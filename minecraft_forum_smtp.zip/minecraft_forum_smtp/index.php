<?php
// index.php
// Dcard 網頁版風格的討論列表：左側分類、中間貼文卡片、右側系統狀態。
require_once __DIR__ . '/functions.php';
start_session_once();
$user = current_user($pdo);

$keyword = trim($_GET['q'] ?? '');
$params = [];
$where = '';
if ($keyword !== '') {
    $where = 'WHERE n.title LIKE ? OR n.content LIKE ? OR u.nickname LIKE ?';
    $like = '%' . $keyword . '%';
    $params = [$like, $like, $like];
}

$sql = "
    SELECT n.id, n.title, n.content, n.created_at,
           u.nickname, u.avatar, u.favorite_color,
           COUNT(r.id) AS reply_count
    FROM news n
    JOIN users u ON u.id = n.user_id
    LEFT JOIN replies r ON r.news_id = n.id
    {$where}
    GROUP BY n.id, n.title, n.content, n.created_at, u.nickname, u.avatar, u.favorite_color
    ORDER BY n.created_at DESC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$posts = $stmt->fetchAll();

page_header('論壇', $user);
?>
<aside class="sidebar left-panel">
    <div class="pixel-card side-card">
        <div class="side-title">伺服器看板</div>
        <a class="side-link active" href="index.php">全部貼文</a>
        <a class="side-link" href="index.php?q=問題">問題求救</a>
        <a class="side-link" href="index.php?q=分享">作品分享</a>
        <a class="side-link" href="index.php?q=公告">系統公告</a>
        <a class="side-link" href="index.php?q=交易">村民交易</a>
    </div>
</aside>

<section class="feed">
    <?php if ($msg = flash_get('success')): ?><div class="alert success"><?= h($msg) ?></div><?php endif; ?>
    <?php if ($msg = flash_get('error')): ?><div class="alert error"><?= h($msg) ?></div><?php endif; ?>

    <div class="pixel-card composer-card">
        <?php if ($user): ?>
            <form action="post.php" method="post" class="composer-form">
                <?= csrf_field() ?>
                <div class="composer-user">
                    <span class="big-avatar" style="background: <?= h($user['favorite_color']) ?>"><?= avatar_icon($user['avatar']) ?></span>
                    <div>
                        <strong><?= h($user['nickname']) ?></strong>
                        <p class="muted">像 Dcard 一樣發一篇討論，但長得比較方。</p>
                    </div>
                </div>
                <input type="text" name="title" maxlength="200" placeholder="標題：今天想討論哪個方塊？" required>
                <textarea name="content" rows="5" maxlength="<?= MAX_POST_LENGTH ?>" placeholder="內容：分享問題、想法、作品或作業 demo 說明..." required></textarea>
                <button class="btn" type="submit">發布貼文</button>
            </form>
        <?php else: ?>
            <div class="login-hint">
                <div class="big-avatar">🧱</div>
                <div>
                    <strong>登入後才能發文與留言</strong>
                    <p class="muted">會員資料會自動套用成暱稱、大頭貼與留言背景色。</p>
                    <a class="btn small" href="login.php">登入</a>
                    <a class="btn secondary small" href="register.php">註冊</a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <form class="search-bar" method="get" action="index.php">
        <input type="text" name="q" value="<?= h($keyword) ?>" placeholder="搜尋貼文、內容或玩家暱稱">
        <button class="btn secondary" type="submit">搜尋</button>
    </form>

    <?php if (!$posts): ?>
        <div class="pixel-card empty-card">目前沒有貼文。這片草原還很安靜。</div>
    <?php endif; ?>

    <?php foreach ($posts as $post): ?>
        <?php $excerpt = mb_substr(trim($post['content']), 0, 120); ?>
        <article class="post-card pixel-card" style="--user-color: <?= h(safe_color($post['favorite_color'])) ?>">
            <a class="post-link" href="show_news.php?id=<?= (int)$post['id'] ?>">
                <div class="post-meta-row">
                    <span class="mini-avatar" style="background: <?= h(safe_color($post['favorite_color'])) ?>"><?= avatar_icon($post['avatar']) ?></span>
                    <span class="nickname"><?= h($post['nickname']) ?></span>
                    <span class="dot">·</span>
                    <span><?= h($post['created_at']) ?></span>
                </div>
                <h2><?= h($post['title']) ?></h2>
                <p><?= h($excerpt) ?><?= mb_strlen($post['content']) > 120 ? '...' : '' ?></p>
                <div class="post-actions">
                    <span>💬 <?= (int)$post['reply_count'] ?> 則留言</span>
                    <span>⛏️ 點擊進入討論串</span>
                </div>
            </a>
        </article>
    <?php endforeach; ?>
</section>

<aside class="sidebar right-panel">
    <div class="pixel-card side-card">
        <div class="side-title">系統任務板</div>
        <ul class="quest-list">
            <li>✅ 會員註冊 / 登入 / 登出</li>
            <li>✅ 暱稱 + 大頭貼顯示</li>
            <li>✅ 留言背景色跟著玩家設定</li>
            <li>✅ Gmail SMTP 寄信</li>
            <li>✅ 管理員會員管理</li>
        </ul>
    </div>
</aside>
<?php page_footer(); ?>
