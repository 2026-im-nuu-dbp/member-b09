<?php
// db_config.php
// 保留老師原始程式常用的檔名，實際連線由 db.php 管理。
// 若舊檔案 require 'db_config.php'，也能取得 $pdo 與 escape()。

require_once __DIR__ . '/db.php';

function escape($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
